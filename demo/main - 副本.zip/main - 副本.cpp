// Copyright (2016) Baidu Inc. All rights reserved.
/**
 * File: main.cpp
 * Desc: Sample code for startup DuerOS
 */

#include "mbed.h"
#include "baidu_media_manager.h"
#include "baidu_media_play.h"
#include "duer_app.h"
#include "events.h"
#include "lightduer_log.h"
#if defined(TARGET_UNO_91H)
#include "SDMMCFileSystem.h"
#include "WiFiStackInterface.h"
#include "factory_test.h"
#include "gpadckey.h"
#ifdef RDA_SMART_CONFIG
#include "smart_config.h"
#endif // RDA_SMART_CONFIG
#elif defined(TARGET_K64F)
#include "SDFileSystem.h"
#include "EthernetInterface.h"
#else
#error "Not supported"
#endif // TARGET_UNO_91H
#include "lightduer_connagent.h"
#include "baidu_ca_network_socket.h"
#if defined(ENABLE_UPNP_RENDER)
#include "minirender.h"
#include "baidu_measure_stack.h"
#endif

#include "duerapp_ota.h"
#include "duerapp_device_info.h"
#include "lightduer_ota_notifier.h"
#include "duer_dcs.h"


#include "mbed.h"
#include "rtos.h"
#include "inet.h"
#include "WiFiStackInterface.h"
#include "rda5981_sniffer.h"
#include "airkiss.h"
#include "gpadckey.h"


#if defined(TARGET_UNO_91H)

// Initialize SD card
SDMMCFileSystem g_sd(GPIO_PIN9, GPIO_PIN0, GPIO_PIN3, GPIO_PIN7, GPIO_PIN12, GPIO_PIN13, "sd");

//static WiFiStackInterface wifi;
#else
SDFileSystem g_sd = SDFileSystem(D11, D12, D13, D10, "sd");
static EthernetInterface wifi;
#endif // TARGET_UNO_91H

const char* ip;
const char* mac;

WiFiStackInterface wifi;

char ssid[32];
char passwd[64];
uint8_t random;
Semaphore airkiss_done(0);

/* airkiss reset */
GpadcKey airkiss_reset_key(KEY_A5);
Timer airkiss_reset_timer;
unsigned int falltime;
void airkiss_reset_irq_fall()
{
    airkiss_reset_timer.start();
    falltime = airkiss_reset_timer.read_ms();
}
void airkiss_reset_irq_rise()
{
    unsigned int time_now = airkiss_reset_timer.read_ms();
    if((time_now - falltime) > 3000) {   //about 5s
        printf("clear ssid saved in flash\r\n");
        rda5981_flash_erase_sta_data();         //long press for recording
    }
    airkiss_reset_timer.stop();
}
void rda5991h_smartlink_irq_init()
{
    printf("%s\r\n", __func__);
    airkiss_reset_key.fall(&airkiss_reset_irq_fall);
    airkiss_reset_key.rise(&airkiss_reset_irq_rise);
}

/* airkiss data */
const airkiss_config_t akconf =
{
	(airkiss_memset_fn)&memset,
	(airkiss_memcpy_fn)&memcpy,
	(airkiss_memcmp_fn)&memcmp,
	(airkiss_printf_fn)&printf
};
airkiss_context_t akcontex;

uint8_t my_scan_channel[15];
int cur_channel = 0;
int to_ds = 1;
int from_ds = 0;
int mgm_frame = 0;
static void time_callback(void const *p)
{
    int i;
    do {
        cur_channel++;
    	if (cur_channel > 13) {
    		cur_channel = 1;
            to_ds = to_ds?0:1;
            from_ds = from_ds?0:1;
    	}
    } while (my_scan_channel[cur_channel] == 0);
    rda5981_start_sniffer(cur_channel, to_ds, from_ds, mgm_frame, 0);
    airkiss_change_channel(&akcontex);
}

RtosTimer timer(time_callback, osTimerPeriodic, 0);

static int send_rsp_to_apk(uint8_t random)
{
    int i;
    int ret;
    int udp_broadcast = 1;
    UDPSocket udp_socket;
    ip_addr_t ip4_addr;
    char host_ip_addr[16];

    memset((u8_t *)(&ip4_addr), 0xff, 4);
    strcpy(host_ip_addr, inet_ntoa(ip4_addr));

    printf("send response to host:%s\n", host_ip_addr);

    ret = udp_socket.open(&wifi);
    if (ret) {
        printf("open socket error:%d\r\n", ret);
        return ret;
    }

    ret = udp_socket.setsockopt(0,NSAPI_UDP_BROADCAST,&udp_broadcast,sizeof(udp_broadcast));
    if (ret) {
        printf("setsockopt error:%d\r\n", ret);
        return ret;
    }

    for (i=0; i<30; ++i) {
        ret = udp_socket.sendto(host_ip_addr, 10000, &random, 1);
        if (ret <= 0)
            printf("send rsp fail%d\n", ret);
        wait_us(100 * 1000);
    }
    printf("send response to host done\n");
    return ret;
}

static void airkiss_finish(void)
{
	int err;
	airkiss_result_t result;
	err = airkiss_get_result(&akcontex, &result);
	if (err == 0)
	{
		printf("airkiss_get_result() ok!");
        printf("ssid = \"%s\", pwd = \"%s\", ssid_length = %d, \"pwd_length = %d, random = 0x%02x\r\n",
        result.ssid, result.pwd, result.ssid_length, result.pwd_length, result.random);
        rda5981_stop_sniffer();
        strcpy(ssid, result.ssid);
        strcpy(passwd, result.pwd);
        random = result.random;
        airkiss_done.release();
	}
	else
	{
		printf("airkiss_get_result() failed !\r\n");
	}
}

static void wifi_promiscuous_rx(uint8_t *buf, uint16_t len)
{
	int ret;
	ret = airkiss_recv(&akcontex, buf, len);
	if ( ret == AIRKISS_STATUS_CHANNEL_LOCKED)
        timer.stop();
	else if ( ret == AIRKISS_STATUS_COMPLETE )
	{
		airkiss_finish();
	}
}

void start_airkiss(void)
{
    int ret;

    ret = airkiss_init(&akcontex, &akconf);
    if (ret < 0)
    {
        printf("Airkiss init failed!\r\n");
        return;
    }
}

int my_smartconfig_handler(unsigned short data_len, void *data)
{
    static unsigned short seq_num = 0, seq_tmp;

    char *frame = (char *)data;

    seq_tmp = (frame[22] | (frame[23]<<8))>>4;
    if (seq_tmp == seq_num)
        return 0;
    else
        seq_num = seq_tmp;
    wifi_promiscuous_rx((uint8_t*)data, data_len);
    return 0;
}


void* baidu_get_netstack_instance(void)
{
    return (void*)&wifi;
}

#if defined(ENABLE_UPNP_RENDER)
void test_upnp_render(void const *argument) {

    Thread::wait(5000);

    printf("### test upnp start\n");

    upnp_test(ip, mac);

    printf("### test upnp end\n");
}
#endif

// main() runs in its own thread in the OS
int main()
{

#if defined(TARGET_UNO_91H)
    // Initialize RDA FLASH
    const unsigned int RDA_FLASH_SIZE     = 0x400000;   // Flash Size
    const unsigned int RDA_SYS_DATA_ADDR  = 0x18204000; // System Data Area, fixed size 4KB
    const unsigned int RDA_USER_DATA_ADDR = 0x18205000; // User Data Area start address
    const unsigned int RDA_USER_DATA_LENG = 0x3000;     // User Data Area Length

    rda5981_set_flash_size(RDA_FLASH_SIZE);
    rda5981_set_user_data_addr(RDA_SYS_DATA_ADDR, RDA_USER_DATA_ADDR, RDA_USER_DATA_LENG);

    // Test added by RDA
    factory_test();
#endif

int i;
    int ret;
    int airkiss_send_rsp = 0;
    rda5981_scan_result scan_result[30];

    memset(my_scan_channel, 0, sizeof(my_scan_channel));

    ret = wifi.scan(NULL, 0);//necessary
    ret = wifi.scan_result(scan_result, 30);
    printf("scan result:%d\n", ret);
    for(i=0; i<ret; ++i) {
        if (scan_result[i].channel<=13) {
            printf("i:%d, channel%d\n", i, scan_result[i].channel);
            my_scan_channel[scan_result[i].channel] = 1;
        }
    }

    rda5991h_smartlink_irq_init();

    ret = rda5981_flash_read_sta_data(ssid, passwd);
    if (ret==0 && strlen(ssid)) {//get ssid from flash
        printf("get ssid from flash: ssid:%s, pass:%s\r\n",
            ssid, passwd);
    } else {//need to smartconfig
        printf("start airkiss, version:%s\n", airkiss_version());
        rda5981_enable_sniffer(my_smartconfig_handler);

        start_airkiss();

        timer.start(200);

        airkiss_done.wait();
        airkiss_send_rsp = 1;
        wait_us(500 * 1000);
    }

    ret = wifi.connect(ssid, passwd, NULL, NSAPI_SECURITY_NONE);
    if (ret==0) {
        printf("connect to %s success, ip %s\r\n", ssid, wifi.get_ip_address());
    } else {
        printf("connect to %s fail\r\n", ssid);
    }

    //if (airkiss_send_rsp) {
        //rda5981_flash_write_sta_data(ssid, passwd);
        //send_rsp_to_apk(random);
    //}

    //while (true) {
    //}
	DUER_LOGI("\nEntry Tinydu Main111>>>>\n");



    DUER_LOGI("\nEntry Tinydu Main>>>>\n");

    // Brings up the network interface
#ifdef RDA_SMART_CONFIG
    typedef void (*dummy_func)();
    mbed::GpadcKey key_erase = mbed::GpadcKey(KEY_A2);
    key_erase.fall((dummy_func)rda5981_flash_erase_sta_data);

    int ret = 0;
    ret = wifi.scan(NULL, 0);//necessary

    char smartconfig_ssid[duer::RDA_SMARTCONFIG_SSID_LENGTH];
    char smartconfig_password[duer::RDA_SMARTCONFIG_PASSWORD_LENGTH];
    ret = duer::smart_config(smartconfig_ssid, smartconfig_password);
    if (ret == 0 && wifi.connect(smartconfig_ssid, smartconfig_password) == 0) {
#elif defined(TARGET_UNO_91H)
    if (wifi.connect(ssid, passwd) == 0) {
#else
    if (wifi.connect() == 0) {
#endif // RDA_SMART_CONFIG
        ip = wifi.get_ip_address();
        mac = wifi.get_mac_address();
        DUER_LOGI("IP address is: %s", ip ? ip : "No IP");
        DUER_LOGI("MAC address is: %s", mac ? mac : "No MAC");
    } else {
        DUER_LOGE("Network initial failed....");
        Thread::wait(osWaitForever);
    }

    // Initialize the Duer OS
    duer_initialize();
    duer_init_device_info();

    duer::MediaManager::instance().initialize();

    duer::SocketAdapter::set_network_interface(&wifi);

    duer::MediaManager::instance().set_volume(duer::DEFAULT_VOLUME);

    duer::DuerApp app;
    app.start();

    duer_set_duerapp_instance(&app);

#if defined(ENABLE_UPNP_RENDER)
    Thread thread(test_upnp_render, NULL, osPriorityNormal, 10*1024);
#if defined(BAIDU_STACK_MONITOR)
    register_thread(&thread, "DLNA");
#endif
#endif

    duer::event_loop();
}
